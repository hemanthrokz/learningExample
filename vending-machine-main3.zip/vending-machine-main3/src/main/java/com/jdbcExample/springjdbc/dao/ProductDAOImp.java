package com.jdbcExample.springjdbc.dao;

import com.jdbcExample.springjdbc.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ProductDAOImp implements ProductDAO {

    @Autowired
    JdbcTemplate jdbcTemplate;

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Override
    public int save(Product product) {
        return jdbcTemplate.update("insert into product_1 (code,name,price,stock) values (?,?,?,?) ", product.getCode(), product.getName(), product.getPrice(), product.getStock());
    }

    @Override
    public int update(Product product, int code) {
        return jdbcTemplate.update("update product_1 set name=?, price=?, stock=? where code = ?", product.getName(), product.getPrice(), product.getStock(), code);
    }

    @Override
    public int delete(int code) {
        return jdbcTemplate.update("delete from product_1 where code = ?", code);
    }


    @Override
    public List<Product> getAll() {

        return jdbcTemplate.query("select * from product_1", new BeanPropertyRowMapper<Product>(Product.class));

    }

    @Override
    public List<Product> getByCode(int code) {
        return jdbcTemplate.query("select * from product_1 where code = ?", new BeanPropertyRowMapper<Product>(Product.class), code);
    }

    public List<Product> getByStock(int stock){
        return jdbcTemplate.query("select * from product_1 where stock < ?",new BeanPropertyRowMapper<Product>(Product.class),stock);
    }


}
