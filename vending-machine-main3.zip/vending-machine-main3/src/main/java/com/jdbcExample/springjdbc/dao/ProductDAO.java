package com.jdbcExample.springjdbc.dao;

import com.jdbcExample.springjdbc.model.Product;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface ProductDAO {


    int save(Product product);

    int update(Product product, int code);

    int delete(int code);

    List<Product> getByCode(int code);

    List<Product> getAll();


}
