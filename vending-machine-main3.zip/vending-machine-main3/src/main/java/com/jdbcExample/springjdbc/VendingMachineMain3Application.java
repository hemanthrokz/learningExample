package com.jdbcExample.springjdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VendingMachineMain3Application {

	public static void main(String[] args) {
		SpringApplication.run(VendingMachineMain3Application.class, args);
	}

}
