package com.jdbcExample.springjdbc.controller;

import com.jdbcExample.springjdbc.dto.UserProductDto;
import com.jdbcExample.springjdbc.model.Product;
import com.jdbcExample.springjdbc.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/vending_machine")
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping("/product")
    public List<UserProductDto> getProduct() {
        return productService.getListOfAllProduct();
    }

    @GetMapping("/product/{code}")
    public Product getByCode(@PathVariable int code) {
        return productService.getProductByCode(code);
    }

    @PostMapping("/AddProduct")
    public String save(@RequestBody Product product) {
        return productService.saveProduct(product) + " product added successfully";
    }

    @PutMapping("/updateProduct/{code}")
    public String update(@RequestBody Product product, @PathVariable int code) {
        return productService.updateProduct(product, code) + " one row updated";
    }

    @DeleteMapping("/deleteProduct/{code}")
    public String deleteProduct(@PathVariable int code) {
        return productService.deleteProductByCode(code) + " product deleted";
    }

    @GetMapping("/getByStockRange")
    public List<Product> getByStock(@RequestParam(value="stock",required = true) int stock){
        return productService.productWithInStockRange(stock);
    }


}
