package com.jdbcExample.springjdbc.service;

import com.jdbcExample.springjdbc.dao.ProductDAOImp;
import com.jdbcExample.springjdbc.dto.UserProductDto;
import com.jdbcExample.springjdbc.exception.CodeNotFoundException;
import com.jdbcExample.springjdbc.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {

    @Autowired
    ProductDAOImp repository;

    public int saveProduct(Product product){
        return repository.save(product);
    }

    public int updateProduct(Product product,int code){
        return repository.update(product,code);
    }

    public List<UserProductDto> getListOfAllProduct(){
        return allProductToUserProduct(repository.getAll());
    }

    public Product getProductByCode(int code){
        if(repository.getByCode(code).isEmpty()){
            throw new CodeNotFoundException("invalid code....!!!!");
        }
        return repository.getByCode(code).get(0);
    }

    public int deleteProductByCode(int code){
        return repository.delete(code);
    }

    public List<Product> productWithInStockRange(int stock){
        return repository.getByStock(stock);
    }
    public UserProductDto productToUserProduct(Product product){
        return new UserProductDto(product.getCode(),product.getName(),product.getPrice());
    }

    public List<UserProductDto> allProductToUserProduct(List<Product> allProduct){
        return  allProduct.stream().map((x)->productToUserProduct(x)).collect(Collectors.toList());
    }

}
