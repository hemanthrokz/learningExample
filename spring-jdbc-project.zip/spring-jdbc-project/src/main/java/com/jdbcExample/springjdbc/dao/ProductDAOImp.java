package com.jdbcExample.springjdbc.dao;

import com.jdbcExample.springjdbc.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ProductDAOImp implements ProductDAO {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public List<Product> getAll() {

        return jdbcTemplate.query("select * from product_1", new BeanPropertyRowMapper<Product>(Product.class));

    }
}
