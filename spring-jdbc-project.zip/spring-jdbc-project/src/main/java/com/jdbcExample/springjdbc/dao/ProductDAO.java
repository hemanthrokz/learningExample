package com.jdbcExample.springjdbc.dao;

import com.jdbcExample.springjdbc.model.Product;

import java.util.List;

public interface ProductDAO {

    List<Product> getAll();
}
