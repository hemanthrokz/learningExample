package com.jdbcExample.springjdbc.controller;

import com.jdbcExample.springjdbc.dao.ProductDAO;
import com.jdbcExample.springjdbc.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
public class ProductController {

    @Autowired
    private ProductDAO pDAO;
    private Product selectedProduct;

    @RequestMapping("/")
    public String viewHomePage(Model model) {
        List<Product> productList = pDAO.getAll();
        Product product = new Product();
        model.addAttribute("productList", productList);
        model.addAttribute("product", product);
        return "index";
    }


}
